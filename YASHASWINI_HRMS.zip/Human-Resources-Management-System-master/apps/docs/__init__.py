default_app_config = "apps.docs.apps.DocsConfig"
