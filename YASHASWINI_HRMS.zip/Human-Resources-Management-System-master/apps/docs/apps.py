from django.apps import AppConfig


class DocsConfig(AppConfig):
    name = "apps.docs"

    # def ready(self):
    #     import apps.docs.signals